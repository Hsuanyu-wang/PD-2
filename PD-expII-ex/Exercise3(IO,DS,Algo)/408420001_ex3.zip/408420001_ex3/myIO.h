#ifndef myIO_H
#define myIO_H
void _build_map();
void _print_relation();
void _check_argument(int, char**);
void _err_message(int);
#define _print(x) printf(#x ": "); _print_relation();
#endif
