#ifndef myDS_H
#define myDS_H
void _stack_push(int);
void _stack_pop();
BOOL _stack_empty();
int _stack_top();
void _queue_push(int);
void _queue_pop();
BOOL _queue_empty();
int _queue_front();
#endif
